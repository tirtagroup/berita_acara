"use strict";window.print();
